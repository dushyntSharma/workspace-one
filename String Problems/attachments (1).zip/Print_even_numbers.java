
public class Print_even_numbers
{
	public static void main(String[] args)
	{
		for(int i=0;i<11;i+=2)
		{
			System.out.println(i);
		}
	}

}
