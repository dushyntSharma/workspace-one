
public class Printing_numbers
{
	public static void main(String[] args)
	{
		int i=0;
		while(i<11)
		{
			System.out.print(i+" ");
			i++;
		}
		System.out.println(" ");
		int j=0;
		do {
			
			System.out.print(j+" ");
			j++;
		}while(j<11);
	}

}
